
const initialState = {}

export default (state = initialState, action) => {
  return state
}
